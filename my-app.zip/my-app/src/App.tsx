
import { Box, VStack, Icon, Flex, Button } from "@chakra-ui/react";
import { Home, Store, Cpu, HardDrive, LogIn, Wallet } from "lucide-react";
import {
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  MenuDivider,
} from "@chakra-ui/react";

import DashboardContent from "./pages/dashboard";
import StoragePage from "./pages/storage";
import MarketplacePage from "./pages/marketplace";

const Dashboard = () => {
  const currentPage = window.location.pathname;

  return (
    <Flex h="100vh">
      <Box w="200px" bg="gray.100" p={5}>
        <VStack align="stretch" spacing={5}>
          {[
            { icon: Home, text: "Dashboard", path: "/" },
            { icon: Store, text: "Marketplace", path: "/marketplace" },
            { icon: Cpu, text: "Runtime", path: "/runtime" },
            { icon: HardDrive, text: "Storage", path: "/storage" },
          ].map((item, index) => (
            <Flex align="center" key={index}>
              <Icon as={item.icon} boxSize={6} mr={2} />
              <Button
                fontSize="md"
                colorScheme={currentPage === item.path ? "blue" : "gray"}
                onClick={() => (window.location.href = item.path)} // Modified onClick event handler
              >
                {item.text}
              </Button>
            </Flex>
          ))}

          <Menu>
            <MenuButton
              leftIcon={<Wallet />}
              as={Button}
              colorScheme="blue"
              size="sm"
              position="fixed"
              bottom="3"
              left="3"
              justifyItems={"bottom"}
            >
              0xcEE96...36efF
            </MenuButton>
            <MenuList>
              <MenuItem><strong>ALEPH</strong>: 15,000</MenuItem>
              <MenuItem><strong>ETH</strong>: 1,3</MenuItem>
              <MenuDivider />
              <MenuItem>
                <Button
                  rightIcon={<Icon as={LogIn} boxSize={4} />}
                  colorScheme="red"
                  variant="solid"
                  size="sm"
                >
                  Logout
                </Button>
              </MenuItem>
            </MenuList>
          </Menu>
        </VStack>
      </Box>

      <Box flex="1" p={5}>
        {currentPage === "/" && <DashboardContent />}
        {currentPage === "/storage" && <StoragePage />}
        {currentPage === "/marketplace" && <MarketplacePage />}
      </Box>
    </Flex>
  );
};

export default Dashboard;

import React from "react";
import { Divider, Grid, GridItem } from "@chakra-ui/react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

import {
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  StatGroup,
} from "@chakra-ui/react";

import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
} from "@chakra-ui/react";

import { Badge } from "@chakra-ui/react";

const MonthlycomputingData = [
  {
    name: "1 Feb",
    storage: 40,
    instance: 24,
  },
  {
    name: "2 Feb",
    storage: 30,
    instance: 13.98,
  },
  {
    name: "3 Feb",
    storage: 20,
    instance: 98,
  },
  {
    name: "4 Feb",
    storage: 27.8,
    instance: 39.08,
  },
  {
    name: "5 Feb",
    storage: 18.9,
    instance: 48,
  },
  {
    name: "6 Feb",
    storage: 23.9,
    instance: 38,
  },
  {
    name: "7 Feb",
    storage: 34.9,
    instance: 43,
  },
];

const MontlyRevenue = [
  {
    name: "1 Feb",
    model_1: 4000,
    model_2: 2400,
    model_3: 2400,
  },
  {
    name: "2 Feb",
    model_1: 3000,
    model_2: 1398,
    model_3: 2210,
  },
  {
    name: "3 Feb",
    model_1: 2000,
    model_2: 9800,
    model_3: 2290,
  },
  {
    name: "4 Feb",
    model_1: 2780,
    model_2: 3908,
    model_3: 2000,
  },
  {
    name: "5 Feb",
    model_1: 1890,
    model_2: 4800,
    model_3: 2181,
  },
  {
    name: "6 Feb",
    model_1: 2390,
    model_2: 3800,
    model_3: 2500,
  },
  {
    name: "7 Feb",
    model_1: 3490,
    model_2: 4300,
    model_3: 2100,
  },
];

const DashboardPage = () => {
  return (
    <Grid templateColumns="repeat(2, 3fr)" gap={4} h="100%">
      <GridItem colSpan={1} bg="gray.100" p={5} borderRadius="md" h={350}>
        <h1>
          <strong>Monthly Usage</strong>
        </h1>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={MonthlycomputingData}>
            <CartesianGrid strokeDasharray="4 4" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="storage" fill="#8884d8" stackId="a" />
            <Bar dataKey="instance" fill="#82ca9d" stackId="a" />
          </BarChart>
        </ResponsiveContainer>
      </GridItem>
      <GridItem colSpan={1} bg="gray.100" p={5} borderRadius="md" h={350}>
        <h1>
          <strong>Monthly Revenue Stream</strong>
        </h1>
        <ResponsiveContainer>
          <AreaChart data={MontlyRevenue}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Area
              type="monotone"
              dataKey="model_1"
              stackId="1"
              stroke="#8884d8"
              fill="#8884d8"
            />
            <Area
              type="monotone"
              dataKey="model_2"
              stackId="1"
              stroke="#82ca9d"
              fill="#82ca9d"
            />
            <Area
              type="monotone"
              dataKey="model_3"
              stackId="1"
              stroke="#ffc658"
              fill="#ffc658"
            />
          </AreaChart>
        </ResponsiveContainer>
      </GridItem>
      <GridItem colSpan={1} bg="gray.100" p={5} borderRadius="md" h={190}>
        <h1>
          <strong>Activity</strong>
        </h1>
        <StatGroup mt={5} alignContent="center" justifyItems="center">
          <Stat>
            <StatLabel>Total Usage Traffic</StatLabel>
            <StatNumber>345,670</StatNumber>
            <StatHelpText>
              <StatArrow type="increase" />
              23.36%
            </StatHelpText>
          </Stat>
          <Stat>
            <StatLabel>Total Download Traffic</StatLabel>
            <StatNumber>4,516</StatNumber>
            <StatHelpText>
              <StatArrow type="decrease" />
              9.05%
            </StatHelpText>
          </Stat>
        </StatGroup>
      </GridItem>

      <GridItem
        colSpan={1}
        bg="gray.100"
        p={5}
        borderRadius="md"
        h={400}
        rowSpan={3}
      >
        <h1>
          <strong>Published Models and Datasets</strong>
        </h1>
        <Table variant="simple" size="sm" mt={5} alignContent="center">
          <Thead>
            <Tr>
              <Th>Name</Th>
              <Th>Status</Th>
              <Th>Downloads</Th>
              <Th>Date</Th>
            </Tr>
          </Thead>
          <Tbody>
            <Tr>
              <Td>Yolov6</Td>
              <Td>
                <Badge colorScheme="green" fontSize="0.8em">
                  Published
                </Badge>
              </Td>
              <Td>25.4k</Td>
              <Td>01/02/2023</Td>
            </Tr>
            <Divider orientation="horizontal" />
            <Tr>
              <Td>Yolov7</Td>
              <Td>
                <Badge colorScheme="green" fontSize="0.8em">
                  Published
                </Badge>
              </Td>
              <Td>12.4k</Td>
              <Td>01/05/2023</Td>
            </Tr>
            <Divider orientation="horizontal" />
            <Tr>
              <Td>Yolov8</Td>
              <Td>
                <Badge colorScheme="green" fontSize="0.8em">
                  Published
                </Badge>
              </Td>
              <Td>25.4k</Td>
              <Td>01/08/2023</Td>
            </Tr>
            <Divider orientation="horizontal" />
            <Tr>
              <Td>LLaMa2</Td>
              <Td>
                <Badge colorScheme="purple" fontSize="0.8em">
                  In Approval
                </Badge>
              </Td>
              <Td>0</Td>
              <Td>29/02/2024</Td>
            </Tr>
            <Divider orientation="horizontal" />
            <Tr>
              <Td>GPT-5.1-preview</Td>
              <Td>
                <Badge colorScheme="red" fontSize="0.8em">
                  Removed
                </Badge>
              </Td>
              <Td>1.4k</Td>
              <Td>01/02/2048</Td>
            </Tr>
            <Divider orientation="horizontal" />
            <Tr>
              <Td>Open-Images-v7 </Td>
              <Td>
                <Badge colorScheme="green" fontSize="0.8em">
                  Published
                </Badge>
              </Td>
              <Td>1.4k</Td>
              <Td>01/02/2048</Td>
            </Tr>
            <Divider orientation="horizontal" />
          </Tbody>
        </Table>
      </GridItem>

      <GridItem colSpan={1} bg="gray.100" p={5} borderRadius="md" h={190}>
        <h1>
          <strong>Earnings</strong>
        </h1>
        <StatGroup mt={3} alignContent="center" justifyItems="center">
          <Stat>
            <StatLabel>Feb Earnings</StatLabel>
            <StatNumber>428 ALEPH</StatNumber>
            <StatHelpText>Feb 01 - Feb 07</StatHelpText>
            <StatHelpText>
              <StatArrow type="increase" />
              3.36%
            </StatHelpText>
          </Stat>
          <Stat>
            <StatLabel>Total Earnings</StatLabel>
            <StatNumber>14,028 ALEPH </StatNumber>
            <StatHelpText>Jan 2023 - Dec 2023</StatHelpText>
            <StatHelpText>
              <StatArrow type="increase" />
              73.36%
            </StatHelpText>
          </Stat>
        </StatGroup>
      </GridItem>
    </Grid>
  );
};
export default DashboardPage;

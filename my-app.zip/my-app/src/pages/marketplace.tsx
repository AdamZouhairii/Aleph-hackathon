import React, { useState } from "react";
import { StarIcon, TimerIcon, DownloadIcon, BadgeHelp } from "lucide-react";
import {
  Box,
  Flex,
  Text,
  Input,
  Icon,
  CheckboxGroup,
  Badge,
  Stack,
  Divider,
  useDisclosure,
  Button,
} from "@chakra-ui/react";

import { Checkbox } from "@chakra-ui/react";

import {
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  StatGroup,
} from '@chakra-ui/react'


import {
  Drawer,
  DrawerBody,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
} from "@chakra-ui/react";

// Define a type for model details for better type checking
type ModelDetails = {
  name: string;
  description: string;
  badge: string;
  badgeColor: string;
  StatDownload: string;
  StatDownloadIncrease: string;
  StatView: string;
  StatViewIncrease: string;
  Size: string;
  type: string;
  // Add more fields as necessary
};

function OpenModelDetails({ modelDetails }: { modelDetails: ModelDetails }) {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const size = "lg"; // Assuming a default size, adjust as necessary

  // Open the drawer when modelDetails changes
  React.useEffect(() => {
    if (modelDetails) {
      onOpen();
    }
  }, [modelDetails, onOpen]);

  return (
    <>
      <Drawer onClose={onClose} isOpen={isOpen} size={size}>
        <DrawerOverlay />
        <DrawerContent>
          <DrawerHeader>{modelDetails?.name || "Model Details"}</DrawerHeader>
          <DrawerBody>
            <Badge colorScheme="blue" variant="outline">
              {modelDetails?.type}
            </Badge> · 
            {modelDetails?.description || "No details available"}
            {modelDetails?.badge && (
              <Badge colorScheme={modelDetails.badgeColor} ml="2">
                {modelDetails.badge}
              </Badge>
            )}
            <Divider my="4" />
            <StatGroup>
                <Stat>
                  <StatLabel>Views</StatLabel>
                  <StatNumber>{modelDetails?.StatView}</StatNumber>
                  <StatHelpText>
                    <StatArrow type='increase' />
                    {modelDetails?.StatViewIncrease}
                  </StatHelpText>
                </Stat>

                <Stat>
                  <StatLabel>Downloads</StatLabel>
                  <StatNumber>{modelDetails?.StatDownload}</StatNumber>
                  <StatHelpText>
                    <StatArrow type='decrease' />
                    {modelDetails?.StatDownloadIncrease}
                  </StatHelpText>
                </Stat>
                <Stat>
                  <StatLabel>Size</StatLabel>
                  <StatNumber>{modelDetails?.Size}</StatNumber>
                </Stat>
              </StatGroup>
              <Divider my="4" />

          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </>
  );
}

const DashboardPage = () => {
  const [currentModel, setCurrentModel] = useState<ModelDetails | null>(null);

  // Example model details, replace with your actual model details
  const models: ModelDetails[] = [
    {
      name: "google/eemma-7b",
      description: "Text Generation · Updated 3 days ago",
      badge: "new",
      badgeColor: "yellow",
      StatDownload: "1.19k",
      StatDownloadIncrease: "12%",
      StatView: "28.9k",
      StatViewIncrease: "18.8%",
      Size: "1.2GB",
      type:"model"

    },
    {
      name: "eu-commission/yolo-v9",
      description: "Text Generation · Updated 3h ago",
      badge: "verified",
      badgeColor: "green",
      StatDownload: "1.19k",
      StatDownloadIncrease: "12%",
      StatView: "28.9k",
      StatViewIncrease: "18.8%",
      Size: "1.2GB",
      type:"model"
    },
    {
      name: "gov-ai/llm-7B",
      description: "Text Generation · Updated 3h ago",
      badge: "official",
      badgeColor: "blue",
      StatDownload: "1.19k",
      StatDownloadIncrease: "12%",
      StatView: "28.9k",
      StatViewIncrease: "18.8%",
      Size: "1.2GB",
      type:"model"
    },
    // Add more models as needed
  ];

  return (
    <Flex>
      <Box w="200px" borderRight="1px" borderColor="gray.200" p="4">
        <Text fontSize="xl" fontWeight="bold" mb="4">
          Marketplace
        </Text>
        <Input placeholder="Filter" mb="4" />
        <Text fontWeight="bold" mb="2">
          Models
        </Text>
        <CheckboxGroup colorScheme="blue" defaultValue={["LLMs", "NLP"]}>
          <Stack>
            <Checkbox value="LLMs">LLMs</Checkbox>
            <Checkbox value="NLP">NLP</Checkbox>
            <Checkbox value="img">Image</Checkbox>
            <Checkbox value="vid">Video</Checkbox>
            <Checkbox value="multi">Multimodal</Checkbox>
          </Stack>
        </CheckboxGroup>
        <Divider my="4" />
        <Text fontWeight="bold" mb="2">
          Datasets
        </Text>
        <CheckboxGroup colorScheme="blue" defaultValue={["text"]}>
          <Stack>
            <Checkbox value="img">Image</Checkbox>
            <Checkbox value="text">Text Classification</Checkbox>
            <Checkbox value="text2">Text Generation</Checkbox>
            <Checkbox value="vid">Video</Checkbox>
          </Stack>
        </CheckboxGroup>
      </Box>
      <Box flex="1" p="4">
        <Flex justifyContent="space-between" mb="2.5">
          <Text fontSize="2xl" fontWeight="bold">
            Models
          </Text>
          <Text fontSize="lg" color="gray.500">
            520,810
          </Text>
        </Flex>
        <Flex mb="4">
          <Input placeholder="Filter by name" size="lg" mr="2" />
        </Flex>
        <Stack spacing="4">
          {models.map((model, index) => (
            <Box
              key={index}
              borderWidth="1px"
              borderRadius="lg"
              overflow="hidden"
              p="4"
              as="button"
              onClick={() => setCurrentModel(model)}
            >
              <Flex alignItems="center" justifyContent="space-between">
                <Flex alignItems="center">
                  <Icon as={StarIcon} color="yellow.400" mr="2" />
                  <Box>
                    <Text fontWeight="bold" align="left">
                      {model.name}
                    </Text>
                    <Text fontSize="sm" color="gray.500">
                      {model.description}
                    </Text>
                  </Box>
                </Flex>
                <Flex alignItems="center">

                  <Badge mr="2" colorScheme={model.badgeColor}>
                    {model.badge}
                  </Badge>
                  <Badge mr="2" colorScheme="blue" variant='outline' >
                    {model.type}
                  </Badge>
                  <Icon as={TimerIcon} color="gray.500" mr="1" />
                  <Text fontSize="sm" color="gray.500" mr="4">
                    1.19k
                  </Text>
                  <Icon as={DownloadIcon} color="gray.500" mr="1" />
                  <Text fontSize="sm" color="gray.500">
                    188
                  </Text>
                </Flex>
              </Flex>
            </Box>
          ))}
        </Stack>
      </Box>
      {currentModel && <OpenModelDetails modelDetails={currentModel} />}
    </Flex>
  );
};

export default DashboardPage;

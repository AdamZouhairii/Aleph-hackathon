import React, { useState, useCallback } from "react";
import {
  Button,
  Text,
  Divider,
  VStack,
  Box,
  Flex,
  HStack,
  Tag,
  TagLeftIcon,
  TagLabel,
  IconButton,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Progress,
} from "@chakra-ui/react";

import { Download, Trash2, FilePlus, CheckCircle2, Upload } from "lucide-react";
import { useDropzone } from "react-dropzone";

// Import Aleph SDK for publishing files



interface PreparedFile {
  file: File;
  name: string;
  date: string;
  size: string;
  status: string;
}

const DashboardPage = () => {
  const [fileList, setFileList] = useState([
    {
      name: "small_dataset_1.csv",
      date: "Oct 10, 2023, 10:54 AM",
      hash: "KBDbHzGynuepRWkfEOGRB",
      status: "Ready",
      size: "1,590 bytes",
    },
    {
      name: "huge_dataset_2.csv",
      date: "Oct 11, 2023, 11:30 AM",
      hash: "KBPDHzGynuepRLWkfEOGRB",
      status: "Ready",
      size: "2.91 GB",
    },
    {
      name: "huge_dataset_3.csv",
      date: "Oct 11, 2023, 11:30 AM",
      hash: "KBPDbHzGynuepRLWkfEORB",
      status: "Ready",
      size: "2.91 GB",
    },
    {
      name: "huge_dataset_4.csv",
      date: "Oct 11, 2023, 11:30 AM",
      hash: "KBPDbHzGynuepRLWkfEOGR",
      status: "Ready",
      size: "2.91 GB",
    },
  ]);
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    date: string;
    size: string;
    hash: string;
    status: string;
  } | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0); // New state for tracking upload progress
  const { isOpen, onOpen, onClose } = useDisclosure();

  const [filesForUpload, setFilesForUpload] = useState<PreparedFile[]>([]); // New state to hold files ready for upload

  const handleFileClick = (file: {
    name: string;
    date: string;
    size: string;
    hash: string;
    status: string;
  }) => {
    setSelectedFile(file);
  };

  // Function to add a new file to the fileList
  const addFileToList = useCallback(
    (file: {
      name: string;
      date: string;
      size: string;
      hash: string;
      status: string;
    }) => {
      setFileList((currentList) => [...currentList, file]);
    },
    []
  );

  // Dropzone setup with modified onDrop
  const { getRootProps, getInputProps } = useDropzone({
    onDrop: (acceptedFiles) => {
      // Prepare files for upload but don't add them to fileList yet
      const preparedFiles = acceptedFiles.map((file) => {
        const currentDate = new Date().toLocaleString();
        return {
          file: file, // Keep the original File object for uploading
          name: file.name,
          date: currentDate,
          size: `${file.size} bytes`, // Adjust formatting as needed
          status: "Pending", // Set initial status as Pending
        };
      });
      setFilesForUpload(preparedFiles); // Update state with files ready for upload
      onOpen(); // Open the modal to let user confirm upload
    },
    // close the modal after file upload
    onFileDialogCancel: onClose,
  });

  const handleUpload = useCallback(async () => {
    // Assuming the URL to your upload endpoint
    const url = "http://127.0.0.1:4444/upload";

    // Iterate over the filesForUpload array to upload each file
    for (const preparedFile of filesForUpload) {
      const formData = new FormData();
      formData.append("file", preparedFile.file);

      try {
        const response = await fetch(url, {
          method: 'POST',
          body: formData,
        });



        const result = await response.json();
        console.log(result); // Handle the response as needed

        // Assuming you want to update the file's status to "Uploaded" in your fileList
        const updatedFile = {
          name: preparedFile.name,
          date: preparedFile.date,
          size: preparedFile.size,
          status: "Uploaded", // Update the status
          hash: result.item_hash || "placeholderHash", // Use the hash from the response or a placeholder
        };

        addFileToList(updatedFile);
      } catch (error) {
        console.error("Error uploading file:", error);
        // Handle the error as needed
      }
    }

    // Reset states after upload
    setFilesForUpload([]);
    setUploadProgress(0); // Reset progress
    onClose(); // Close the modal
  }, [filesForUpload, onClose, addFileToList]);

  const handleDeleteFile = useCallback(() => {
    if (selectedFile) {
      setFileList((currentList) =>
        currentList.filter((file) => file.hash !== selectedFile.hash)
      );
      setSelectedFile(null); // Optionally reset the selected file
    }
  }, [selectedFile, setFileList]);

  return (
    <Flex h="100vh">
      <Flex flex="1" p="5">
        {/* Left panel - File list */}
        <VStack align="stretch" w="60%" pr="2.5" spacing="5">
          <Text fontSize="2xl" fontWeight="bold">
            Storage
          </Text>
          {fileList.map((file, index) => (
            <Button
              key={index}
              variant="ghost"
              onClick={() => handleFileClick(file)}
            >
              <Flex justifyContent="space-between" width="100%">
                <Text fontSize="l">{file.name}</Text>
                <Text color="gray.500">{file.date}</Text>
              </Flex>
            </Button>
          ))}
          <Button variant="ghost">Load more</Button>
        </VStack>
        <Divider orientation="vertical" />
        {/* Right panel - File details */}
        <VStack align="stretch" w="40%" pl="2.5" spacing="5">
          <Text fontSize="2xl" fontWeight="bold">
            File Info
          </Text>
          {selectedFile && (
            <Box p="5">
              <VStack align="stretch" spacing="4">
                <Text fontSize="xl" fontWeight="bold">
                  {selectedFile.name}
                </Text>
                <Divider />
                <HStack justifyContent="space-between">
                  <VStack align="start" spacing="2">
                    <Text>File Hash</Text>
                    <Text fontWeight="bold">{selectedFile.hash}</Text>
                    <Text>Status</Text>
                    <Tag size="lg" variant="subtle" colorScheme="green">
                      <TagLeftIcon boxSize="12px" as={CheckCircle2} />
                      <TagLabel>Ready</TagLabel>
                    </Tag>
                    <Text>Size</Text>
                    <Text>{selectedFile.size}</Text>
                    <Text>Created at</Text>
                    <Text>{selectedFile.date}</Text>
                  </VStack>
                  <HStack>
                    <IconButton aria-label="Download" icon={<Download />} />
                    <IconButton
                      aria-label="Delete"
                      icon={<Trash2 />}
                      colorScheme="red"
                      onClick={handleDeleteFile}
                    />
                    <IconButton
                      aria-label="Add To Runtime"
                      icon={<FilePlus />}
                      colorScheme="blue"
                    />
                  </HStack>
                </HStack>
              </VStack>
            </Box>
          )}
        </VStack>
        <Button
          leftIcon={<Upload />}
          colorScheme="blue"
          size="md"
          onClick={onOpen}
        >
          <Text fontSize="xl" fontWeight="bold">
            Upload
          </Text>
        </Button>

        {/* Modal for file upload */}
        <Modal isOpen={isOpen} onClose={onClose}>
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>Upload File</ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              {/* Dropzone for file upload */}
              <div
                {...getRootProps({ className: "dropzone" })}
                style={{
                  border: "2px dashed gray",
                  padding: "20px",
                  textAlign: "center",
                }}
              >
                <input {...getInputProps()} />
                <p>Drag 'n' drop some files here, or click to select files</p>
              </div>
              {uploadProgress > 0 && (
                <Progress hasStripe value={uploadProgress} mb={4} />
              )}
            </ModalBody>
            <ModalFooter>
              <Button
                colorScheme="blue"
                mr={3}
                onClick={handleUpload}
                disabled={uploadProgress !== 0}
              >
                {uploadProgress === 100 ? "Uploaded" : "Confirm Upload"}
              </Button>
              <Button onClick={onClose}>Close</Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      </Flex>
    </Flex>
  );
};

export default DashboardPage;
